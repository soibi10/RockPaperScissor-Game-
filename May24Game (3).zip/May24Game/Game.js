const GameState = Object.freeze({
    WELCOMING:   Symbol("welcoming"),
    PLAYING: Symbol("Playing")
    //this game has two states
});

export default class Game{
    constructor(){
        //set the initial state to welcoming
        this.stateCur = GameState.WELCOMING;
    }
    
    makeAMove(sInput)
    {
        let sReply = "Shima :)";
        switch(this.stateCur){
            case GameState.WELCOMING:
            //10 is not included
            this.nComputer = Math.ceil(Math.random() * 99);
                sReply = "I am thinking of a number between 1 and 100 ... Please guess";
                this.stateCur = GameState.PLAYING;
                break;
            case GameState.PLAYING:
                //const aAnswers = ["Yes", "No", "Maybe", "Probably", "For sure!"];
                //const nAnswers = Math.floor(Math.random() * aAnswers.length);
                //sReply = aAnswers[nAnswers];
                //go for the number guessing:
                if(sInput > this.nComputer){
                    sReply = "Too high, try again.";
                }else if(sInput < this.nComputer){
                    sReply = "Too low, try again.";
                }
                else if(sInput == this.nComputer){
                    sReply = "You are right ... I just thought of another number, please guess";
                    this.nComputer = Math.ceil(Math.random() * 99);
                }
                break;
                }
        
        return([sReply]);
    }
}